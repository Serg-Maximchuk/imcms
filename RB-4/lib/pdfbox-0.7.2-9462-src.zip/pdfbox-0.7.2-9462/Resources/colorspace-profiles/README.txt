Java[tm] Advanced Imaging 1.1.2
These color profiles were downloaded from
http://java.sun.com/products/java-media/jai/downloads/download-1_1_2.html

Please read the license in the licenses directory.

The only profile that is actually used is the CMYK.pf, the others are unused but the license states
that redistribute must include the complete software package so the other profiles are included
as well.  